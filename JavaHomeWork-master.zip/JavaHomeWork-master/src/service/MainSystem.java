package service;

public interface MainSystem {
    public void run();
}
