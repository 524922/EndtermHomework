package service;

import etity.Player;
import etity.Project;
import etity.Score;

public interface Inputable {
    public Player playerInput();

    public Project projectInput();

}
