package service;

import etity.Project;

public interface ScoreManager {
    public void recordIt(String project);
    public void printRecord(String  project);
}
