package service;

import etity.Project;

public interface ProjectManager {
    public boolean addProject(Project project);
    public boolean cancelProject(Project project);
}
