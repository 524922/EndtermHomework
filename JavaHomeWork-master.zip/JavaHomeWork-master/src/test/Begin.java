package test;

import service.impl.MainSystemImpl;

public class Begin {
    public static void main(String[] args) {
        MainSystemImpl mainSystem = new MainSystemImpl();
        mainSystem.run();
    }
}

